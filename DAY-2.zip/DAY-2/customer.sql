use WPT;

create table Customer
(
ID int primary key auto_increment,
`NAME` varchar(20), 
EMAIL varchar(30), 
MOBILENO bigint, 
USERNAME varchar(15), 
`PASSWORD` varchar(8)
);

drop table Customer;
select * from Customer;

create database Hibernate;
use Hibernate;