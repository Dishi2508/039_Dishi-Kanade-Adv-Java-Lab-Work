package cdac;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

//Data Access Object - any class in java that contains database code or code to connect with the database should be written in a dao class
public class EmployeeDao {
	
	//public void add(List<Employee> emp) - for inserting multiple employees at once
	public void add(Employee emp) {
		
		//During this step the persistence.xml file will be read
		//and tables will be created in the database if feature enabled
				EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
				EntityManager em = emf.createEntityManager(); //provides methods to talk to the database
				EntityTransaction tx = em.getTransaction();
				tx.begin();
				
				//for(Employee e : emp) - for inserting multiple employees at once
				em.persist(emp); //persist method will generate insert query
				
				tx.commit();
				
				emf.close();
	}
	
	public Employee fetch(int empno) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		
		//find method generates select query where primary key = ?
		
		Employee emp = em.find(Employee.class, empno); //first parameter - table name given indirectly as class is mapped and second parameter is pk ie empno
		//find() is used to fetch data only based on pk.
		
		emf.close();
		
		return emp;
	}
	
	public List<Employee> fetchAll() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		
		Query q = em.createQuery("select e from Employee e"); //HQL/JPQL - Hibernate query language/ java persistence query language
		/*Employee class in select query
		 select e from is same as select * from in mysql */
		
		List<Employee> list = q.getResultList(); //result is in the form of objects of Employee class
		
		emf.close();
		
		return list;
	}
	
	public List<Employee> fetchAllBySalary(double salary) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		
		Query q = em.createQuery("select e from Employee e where e.salary >= :sal"); //HQL/JPQL - Hibernate query language/ java persistence query language
		/*Employee class in select query
		 select e from is same as select * from in mysql */
		q.setParameter("sal", salary); //replace placeholder sal with actual value of salary ie passed
		
		@SuppressWarnings("unchecked")
		List<Employee> list = q.getResultList(); //result is in the form of objects of Employee class
		
		emf.close();
		
		return list;
	}
	
	public List<String> fetchAllNames() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		
		Query q = em.createQuery("select e.name from Employee e"); //HQL/JPQL - Hibernate query language/ java persistence query language
		/*Employee class in select query
		 select e from is same as select * from in mysql */
		
		List<String> list = q.getResultList(); //result is in the form of objects of Employee class
		
		emf.close();
		
		return list;
	}
	
	public List<Object[]> fetchAllNamesAndSalary() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager();
		
		Query q = em.createQuery("select e.name, e.salary from Employee e"); //HQL/JPQL - Hibernate query language/ java persistence query language
		/*Employee class in select query
		 select e from is same as select * from in mysql 
		 name and salary are class property names and not column names..table columns are already mapped by class properties*/
		
		List<Object[]> list = q.getResultList(); //result is in the form of objects of Employee class
		
		emf.close();
		
		return list;
	}
}
