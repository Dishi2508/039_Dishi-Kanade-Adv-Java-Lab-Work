package cdac;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class CustomerAddressDao {
public void add(Customer cust) {
		
		//During this step the persistence.xml file will be read
				EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
				EntityManager em = emf.createEntityManager(); //provides methods to talk to the database
				EntityTransaction tx = em.getTransaction();
				tx.begin();
				
				//for(Employee e : emp) - for inserting multiple employees at once
				em.persist(cust); //persist method will generate insert query
				
				tx.commit();
				
				emf.close();
	}

public void update(Customer cust) {
	
	//During this step the persistence.xml file will be read
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
			EntityManager em = emf.createEntityManager(); //provides methods to talk to the database
			EntityTransaction tx = em.getTransaction();
			tx.begin();
			
			//for(Employee e : emp) - for inserting multiple employees at once
			em.merge(cust); //merge method will generate update query
			
			tx.commit();
			
			emf.close();
}

public Customer fetchCustomer(int id) {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
	EntityManager em = emf.createEntityManager();
	
	//find method generates select query where primary key = ?
	
	Customer emp = em.find(Customer.class, id); //first parameter - table name given indirectly as class is mapped and second parameter is pk ie empno
	//find() is used to fetch data only based on pk.
	
	emf.close();
	
	return emp;
}

public List<Customer> fetchCustomersByEmail(String domain) {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
	EntityManager em = emf.createEntityManager();
	
	Query q = em.createQuery("select c from Customer c where c.email like :em"); //HQL/JPQL - Hibernate query language/ java persistence query language
	/*Employee class in select query
	 select e from is same as select * from in mysql */
	q.setParameter("em", "%" + domain + "%"); //replace placeholder sal with actual value of salary ie passed
	
	@SuppressWarnings("unchecked")
	List<Customer> list = q.getResultList(); //result is in the form of objects of Employee class
	
	emf.close();
	
	return list;
}

public List<Customer> fetchCustomersByCityNames(String city) {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
	EntityManager em = emf.createEntityManager();
	
	Query q = em.createQuery("select c from Customer c join c.address a where a.city = :ct"); //HQL/JPQL - Hibernate query language/ java persistence query language
	//select * from Customer join(c.address - address is object of address class and a is alias of Address Table)-- no need to write on after join, hibernate will automatically map pk and fk
	/*Employee class in select query
	 select e from is same as select * from in mysql */
	q.setParameter("ct", city); //replace placeholder sal with actual value of salary ie passed
	
	@SuppressWarnings("unchecked")
	List<Customer> list = q.getResultList(); //result is in the form of objects of Employee class
	
	emf.close();
	
	return list;
}

public void add(Address addr) {
	
	//During this step the persistence.xml file will be read
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
			EntityManager em = emf.createEntityManager(); //provides methods to talk to the database
			EntityTransaction tx = em.getTransaction();
			tx.begin();
			
			//for(Employee e : emp) - for inserting multiple employees at once
			em.persist(addr); //persist method will generate insert query
			
			tx.commit();
			
			emf.close();
}	

public Address fetchAddress(int id) {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
	EntityManager em = emf.createEntityManager();
	
	//find method generates select query where primary key = ?
	
	Address addr = em.find(Address.class, id); //first parameter - table name given indirectly as class is mapped and second parameter is pk ie empno
	//find() is used to fetch data only based on pk.
	
	emf.close();
	
	return addr;
}

public Address fetchAddressByCustomerName(String name) {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
	EntityManager em = emf.createEntityManager();
	
	Query q = em.createQuery("select a from Customer c join c.address a where c.name = :nm"); //HQL/JPQL - Hibernate query language/ java persistence query language
	//select * from Customer join(c.address - address is object of address class and a is alias of Address Table)-- no need to write on after join, hibernate will automatically map pk and fk
	/*Employee class in select query
	 select e from is same as select * from in mysql */
	q.setParameter("nm", name); //replace placeholder sal with actual value of salary ie passed
	
	@SuppressWarnings("unchecked")
	Address addr = (Address) q.getSingleResult(); //result is in the form of objects of Employee class
	
	emf.close();
	
	return addr;
}



}
