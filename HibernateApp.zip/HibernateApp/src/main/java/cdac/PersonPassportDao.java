package cdac;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class PersonPassportDao {
	
public void add(Person person) {
		
		//During this step the persistence.xml file will be read
				EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
				EntityManager em = emf.createEntityManager(); //provides methods to talk to the database
				EntityTransaction tx = em.getTransaction();
				tx.begin();
				
				//for(Employee e : emp) - for inserting multiple employees at once
				em.persist(person); //persist method will generate insert query
				
				tx.commit();
				
				emf.close();
}

public Person fetchPersonByPassportNo(int passportNo) {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
	EntityManager em = emf.createEntityManager();

	Query q = em.createQuery("select p from Person p join p.passport ps where ps.passportNo = :pno");
	q.setParameter("pno", passportNo);
	Person p = (Person) q.getSingleResult(); //since passportNo is unique for a person so we know that we will get a single result as output
	emf.close();

	return p;
}

public List<Person> fetchPersonByPassportExpiryYear(int year) {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
	EntityManager em = emf.createEntityManager();

	Query q = em.createQuery("select p from Person p join p.passport ps where year(ps.expiryDate) = :yr");
	q.setParameter("yr", year);
	List<Person> list = q.getResultList(); //since passportNo is unique for a person so we know that we will get a single result as output
	emf.close();

	return list;
}

}
