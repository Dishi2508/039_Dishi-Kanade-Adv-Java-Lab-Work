package cdac;

import java.util.List;

public class AddCustomerAndAddress {
	
	public static void main(String args[]) {
		CustomerAddressDao dao = new CustomerAddressDao();
		
		/*Customer c = new Customer();
		c.setName("Dishi");
		c.setEmail("dishi@gmail.com");
		dao.add(c);
		
		//cust_id and addr_id is auto-generated
		
		Address a =  new Address();
		a.setPincode(462039);
		a.setCity("Bhopal");
		a.setState("Madhya Pradesh");
		dao.add(a);*/
		
		/*Customer c = dao.fetchCustomer(1);
		Address a = dao.fetchAddress(1);
		
		c.setAddress(a);
		dao.update(c);*/
		
		/*Customer c = new Customer();
		c.setName("Chinmay");
		c.setEmail("chinmay@gmail.com");
		
		//cust_id and addr_id is auto-generated
		
		Address a =  new Address();
		a.setPincode(400214);
		a.setCity("Yavatmal");
		a.setState("Maharashtra");
		
		c.setAddress(a);
		dao.add(c);*/
		
		/*what we need is if the customer data is inserted the address of the customer should also be inserted automatically
		 to do so we use cascade property (code in Customer.java)*/
		
		/*Customer c = new Customer();
		c.setName("Divyani");
		c.setEmail("divyani@outlook.com");
		
		//cust_id and addr_id is auto-generated
		
		Address a =  new Address();
		a.setPincode(400614);
		a.setCity("Amravati");
		a.setState("Maharashtra");
		
		c.setAddress(a);
		dao.add(c);*/
		
		/*List<Customer> list = dao.fetchCustomersByEmail("gmail");
				for(Customer c : list)
					System.out.println(c.getId() + " " + c.getName() + " " + c.getEmail());*/
				
			/*	List<Customer> list = dao.fetchCustomersByCityNames("bhopal");
				for(Customer c : list)
					System.out.println(c.getId() + " " + c.getName() + " " + c.getEmail());*/
	
	
	Address a = dao.fetchAddressByCustomerName("Chinmay");
	System.out.println(a.getId() + " " + a.getCity() + " " + a.getPincode() + " " + a.getState());
	
  }


}
