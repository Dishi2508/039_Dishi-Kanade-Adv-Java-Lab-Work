package cdac;

import java.time.LocalDate;
import java.util.List;

public class AlbumSongMain {
	
	public static void main(String args [ ]) {
		//GenericDao dao = new GenericDao();
		
		//adding an album
		/*Album album = new Album();
		album.setName("Hits of 2021");
		album.setReleaseDate(LocalDate.of(2021, 8, 25));
		album.setCopyright("Sony Music");
		dao.save(album);*/
		
		/*Album album = new Album();
		album.setName("Hits of 2020");
		album.setReleaseDate(LocalDate.of(2020, 02, 04));
		album.setCopyright("Amazon Music");
		dao.save(album);*/
		
		
		//Adding song to the album
		/*Album album = (Album) dao.fetchById(Album.class, 1);
		Song song = new Song();
		song.setTitle("Shape Of You");
		song.setArtist("Ed Sheeran");
		song.setDuration(3.45);
		song.setAlbum(album);
		dao.save(song);*/
		
		/*Album album = (Album) dao.fetchById(Album.class, 1);
		Song song = new Song();
		song.setTitle("Love Story");
		song.setArtist("Taylor Swift");
		song.setDuration(4.35);
		song.setAlbum(album);
		dao.save(song);*/
		
		/*Album album = (Album) dao.fetchById(Album.class, 1);
		Song song = new Song();
		song.setTitle("Tera Chehra");
		song.setArtist("Adnan Sami");
		song.setDuration(3.25);
		song.setAlbum(album);
		dao.save(song);*/
		
		/*Album album = (Album) dao.fetchById(Album.class, 2);
		Song song = new Song();
		song.setTitle("Rangi Saari");
		song.setArtist("Kanishk");
		song.setDuration(3.25);
		song.setAlbum(album);
		dao.save(song);*/
		
		/*Album album = (Album) dao.fetchById(Album.class, 2);
		Song song = new Song();
		song.setTitle("Thousand Years");
		song.setArtist("Christina Peri");
		song.setDuration(4.50);
		song.setAlbum(album);
		dao.save(song);*/
		
		AlbumSongDao dao = new AlbumSongDao();
		/*List<Song> songs = dao.fetchSongsSungBy("Taylor Swift");
		for(Song song : songs)
			System.out.println(song.getTitle() + " " + song.getDuration());*/
		
		//understanding lazy and eager loading
		/*Album album = (Album) dao.fetchById(Album.class, 1);
		System.out.println(album.getName() + " " + album.getCopyright() + " " + album.getReleaseDate());
		List<Song> songs = album.getSongs();
		for(Song song : songs)
			System.out.println(song.getTitle() + "  " + song.getArtist() + " " + song.getDuration());*/
		
		Song song = (Song) dao.fetchById(Song.class, 3);
		System.out.println(song.getTitle() + "  " + song.getArtist() + " " + song.getDuration());
		Album album = song.getAlbum();
		System.out.println(album.getName() + " " + album.getCopyright() + " " + album.getReleaseDate());
		
	
	}

}
