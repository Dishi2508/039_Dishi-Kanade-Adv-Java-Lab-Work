package cdac;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class ImprovedEmployeeDao {
	
	private static EntityManagerFactory emf;
	
	static {
		emf = Persistence.createEntityManagerFactory("learning-hibernate");
		Runtime.getRuntime().addShutdownHook(new Thread(() -> emf.close()));
	}
	
public void add(Employee emp) {
		
		//During this step the persistence.xml file will be read
				
				EntityManager em = emf.createEntityManager(); //provides methods to talk to the database
				EntityTransaction tx = em.getTransaction();
				tx.begin();
				
				//for(Employee e : emp) - for inserting multiple employees at once
				em.persist(emp); //persist method will generate insert query
				
				tx.commit();
				
	}
	
	public Employee fetch(int empno) {
		EntityManager em = emf.createEntityManager();
		
		//find method generates select query where primary key = ?
		
		Employee emp = em.find(Employee.class, empno); //first parameter - table name given indirectly as class is mapped and second parameter is pk ie empno
		//find() is used to fetch data only based on pk.
		
		
		return emp;
	}
	
	public List<Employee> fetchAll() {
		EntityManager em = emf.createEntityManager();
		
		Query q = em.createQuery("select e from Employee e"); //HQL/JPQL - Hibernate query language/ java persistence query language
		/*Employee class in select query
		 select e from is same as select * from in mysql */
		
		List<Employee> list = q.getResultList(); //result is in the form of objects of Employee class
		
		return list;
	}
	
	public List<Employee> fetchAllBySalary(double salary) {
		EntityManager em = emf.createEntityManager();
		
		Query q = em.createQuery("select e from Employee e where e.salary >= :sal"); //HQL/JPQL - Hibernate query language/ java persistence query language
		/*Employee class in select query
		 select e from is same as select * from in mysql */
		q.setParameter("sal", salary); //replace placeholder sal with actual value of salary ie passed
		
		@SuppressWarnings("unchecked")
		List<Employee> list = q.getResultList(); //result is in the form of objects of Employee class
		
		return list;
	}
	
	public List<String> fetchAllNames() {
		EntityManager em = emf.createEntityManager();
		
		Query q = em.createQuery("select e.name from Employee e"); //HQL/JPQL - Hibernate query language/ java persistence query language
		/*Employee class in select query
		 select e from is same as select * from in mysql */
		
		List<String> list = q.getResultList(); //result is in the form of objects of Employee class
		
		return list;
	}
	
	public List<Object[]> fetchAllNamesAndSalary() {
		EntityManager em = emf.createEntityManager();
		
		Query q = em.createQuery("select e.name, e.salary from Employee e"); //HQL/JPQL - Hibernate query language/ java persistence query language
		/*Employee class in select query
		 select e from is same as select * from in mysql */
		
		List<Object[]> list = q.getResultList(); //result is in the form of objects of Employee class
		
		return list;
	}
}



