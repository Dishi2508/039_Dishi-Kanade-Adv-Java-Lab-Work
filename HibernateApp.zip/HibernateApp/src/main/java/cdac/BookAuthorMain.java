package cdac;

import java.util.ArrayList;
import java.util.List;

public class BookAuthorMain {

	public static void main(String args[]) {
		GenericDao dao = new GenericDao();

		// adding few authors
		/*
		 * Author author = new Author(); author.setName("Eric Freeman");
		 * author.setEmail("eric@gmail.com"); dao.save(author);
		 */

		/*
		 * Author author = new Author(); author.setName("Elizabeth Robson");
		 * author.setEmail("elizabeth@gmail.com"); dao.save(author);
		 */

		// adding book along with author details
		/*
		 * Book book = new Book(); book.setName("Head First Design Patterns");
		 * book.setCost(2500);
		 * 
		 * List<Author> authors = new ArrayList<>();
		 * authors.add((Author)dao.fetchById(Author.class, 1));
		 * authors.add((Author)dao.fetchById(Author.class, 2));
		 * 
		 * book.setAuthors(authors); dao.save(book);
		 */

		// assuming that first we want to add the book
		/*
		 * Book book = new Book(); book.setName("Head First JavaScript");
		 * book.setCost(1500); dao.save(book);
		 */

		// then mention the authors
		/*
		 * Book book = (Book) dao.fetchById(Book.class, 2); List<Author> authors = new
		 * ArrayList<>(); authors.add((Author)dao.fetchById(Author.class, 1));
		 * authors.add((Author)dao.fetchById(Author.class, 2));
		 * 
		 * book.setAuthors(authors); dao.save(book);
		 */

		// adding a book along with some authors
		// adding a book along with authors
		/*
		 * Book book = new Book(); book.setName("Groovy 2 Cookbook");
		 * book.setCost(3000);
		 * 
		 * Author author1 = new Author(); author1.setName("Andrey Adamovich");
		 * author1.setEmail("andrey@gmail.com");
		 * 
		 * Author author2 = new Author(); author2.setName("Luciano Flandesio");
		 * author2.setEmail("luciano@gmail.com");
		 * 
		 * List<Author> list = new ArrayList<>(); list.add(author1); list.add(author2);
		 * 
		 * book.setAuthors(list); // till here the object is transient as object is only
		 * in the memory and data // not inserted in the database
		 * 
		 * dao.save(book); // now the object is in persistent state as data is inserted
		 * in the database
		 */

		/*
		 * Book book = new Book(); book.setName("Good Omens"); book.setCost(3500);
		 * 
		 * Author author1 = new Author(); author1.setName("Neil Gaiman");
		 * author1.setEmail("neil@gmail.com");
		 * 
		 * Author author2 = new Author(); author2.setName("Terry Pratchett.");
		 * author2.setEmail("terry@gmail.com");
		 * 
		 * List<Author> list = new ArrayList<>(); list.add(author1); list.add(author2);
		 * 
		 * book.setAuthors(list); // till here the object is transient as object is only
		 * in the memory and data // not inserted in the database
		 * 
		 * dao.save(book); // now the object is in persistent state as data is inserted
		 * in the database
		 */

		/*Book book = new Book();
		book.setName("Heads You Lose");
		book.setCost(2500);

		Author author1 = new Author();
		author1.setName("Lisa Lutz");
		author1.setEmail("lisa@gmail.com");

		Author author2 = new Author();
		author2.setName("David Hayward");
		author2.setEmail("david@gmail.com");

		List<Author> list = new ArrayList<>();
		list.add(author1);
		list.add(author2);

		book.setAuthors(list);
		// till here the object is transient as object is only in the memory and data
		// not inserted in the database

		dao.save(book);
		// now the object is in persistent state as data is inserted in the database
		*/
		

		Book book1 = new Book();
		book1.setName("American Gods");
		book1.setCost(2500);

		List<Author> authors = new ArrayList<>();
		authors.add((Author) dao.fetchById(Author.class, 5));
		authors.add((Author) dao.fetchById(Author.class, 6));

		book1.setAuthors(authors);
		dao.save(book1);

	}

}
