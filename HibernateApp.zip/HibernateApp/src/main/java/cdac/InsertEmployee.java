package cdac;

import java.time.LocalDate;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import cdac.Employee;

@SuppressWarnings("unused")
public class InsertEmployee {
	
	public static void main(String args[]) {
		
		/*Employee emp = new Employee();
		emp.setEmpno(1005);
		emp.setName("Dhiraj");
		emp.setSalary(50000);
		emp.setDateOfJoining(LocalDate.of(2022, 01, 04));
		
		EmployeeDao dao = new EmployeeDao();
		dao.add(emp);*/
		
		//find method
		
		/*EmployeeDao dao = new EmployeeDao();
		Employee emp = dao.fetch(1004);
		System.out.println(emp.getName() + " " + emp.getSalary());*/
		
		//Query - to write own select statements
		
		/*EmployeeDao dao = new EmployeeDao();
		List<Employee> list = dao.fetchAll();
		for(Employee emp : list)
			System.out.println(emp.getEmpno() + " " + emp.getName() + " " + emp.getSalary() + " " + emp.getDateOfJoining()); 
		
		System.out.println("----------------------");*/
		
		EmployeeDao dao = new EmployeeDao();
		List<Employee> list2 = dao.fetchAllBySalary(65000);
		for(Employee emp : list2)
			System.out.println(emp.getEmpno() + " " + emp.getName() + " " + emp.getSalary() + " " + emp.getDateOfJoining()); 
		
		/*System.out.println("----------------------");
		
		List<String> names = dao.fetchAllNames();
		for(String name : names)
			System.out.println(name); 
		
		
       System.out.println("----------------------");
		
		List<Object[]> namesAndSalaries = dao.fetchAllNamesAndSalary();
		for(Object[] arr : namesAndSalaries)
			System.out.println(arr[0] + " " + arr[1]); */
		
		//During this step the persistence.xml file will be read
		/*EntityManagerFactory emf = Persistence.createEntityManagerFactory("learning-hibernate");
		EntityManager em = emf.createEntityManager(); //provides methods to talk to the database
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Employee emp = new Employee();
		emp.setEmpno(1001);
		emp.setName("Dishi");
		emp.setSalary(70000);
		emp.setDateOfJoining(LocalDate.of(2022, 02, 04));
		
		emp.setEmpno(1002);
		emp.setName("Chinmay");
		emp.setSalary(60000);
		emp.setDateOfJoining(LocalDate.of(2022, 03, 29));
		
		emp.setEmpno(1003);
		emp.setName("Ashutosh");
		emp.setSalary(65000);
		emp.setDateOfJoining(LocalDate.of(2022, 04, 01));
		
		emp.setEmpno(1004);
		emp.setName("Divyani");
		emp.setSalary(60000);
		emp.setDateOfJoining(LocalDate.of(2022, 05, 12));
		
		em.persist(emp); //persist method will generate insert query
		
		tx.commit();
		
		emf.close();*/
	}

}
