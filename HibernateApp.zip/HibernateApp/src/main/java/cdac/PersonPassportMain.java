package cdac;

import java.time.LocalDate;
import java.util.List;

public class PersonPassportMain {
	
	public static void main(String args[ ]) {
		PersonPassportDao dao = new PersonPassportDao();
		
		//Person p = new Person();
		/*p.setName("Shantanu");
		p.setEmail("shantanu@gmail.com");
		p.setDateOfBirth(LocalDate.of(1998, 02, 04));
		
		Passport ps = new Passport();
		ps.setIssueDate(LocalDate.of(2020, 10, 30));
		ps.setExpiryDate(LocalDate.of(2030, 10, 30));
		ps.setIssueBy("Gov. of India");
		
		p.setPassport(ps);/*BIDIRECTIONAL
		ps.setPerson(p); /*RELATIONSHIP
		
		dao.add(p);*/
		
		/*p.setName("Dishi");
		p.setEmail("dishi@gmail.com");
		p.setDateOfBirth(LocalDate.of(1997, 8, 25));
		
		Passport ps = new Passport();
		ps.setIssueDate(LocalDate.of(2020, 11, 30));
		ps.setExpiryDate(LocalDate.of(2030, 11, 30));
		ps.setIssueBy("Gov. of India");
		
		p.setPassport(ps);
		ps.setPerson(p); 
		
		dao.add(p);*/
		
		/*p.setName("Nishad");
		p.setEmail("nishad@gmail.com");
		p.setDateOfBirth(LocalDate.of(1999, 07, 05));
		
		Passport ps = new Passport();
		ps.setIssueDate(LocalDate.of(2020, 03, 15));
		ps.setExpiryDate(LocalDate.of(2030, 03, 15));
		ps.setIssueBy("Gov. of India");
		
		p.setPassport(ps);
		ps.setPerson(p); 
		
		dao.add(p);*/
		
		/*Person p = dao.fetchPersonByPassportNo(3);
		System.out.println(p.getName() + " " + p.getEmail());*/
		
		List<Person> list = dao.fetchPersonByPassportExpiryYear(2030);
		for(Person p : list)
			System.out.println(p.getName() + " " + p.getEmail());
	}

}
