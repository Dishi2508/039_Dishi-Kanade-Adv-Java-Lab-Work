package cdac;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

//CUSTOMER AND CUSTOMER ADDRESS ONE TO ONE ASSOCIATION

@Entity
@Table(name = "Customer_Table")
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) //auto-generated primary key
	@Column(name = "cust_id")
	private int id;
	
	//If column name is same as variable name then no need to define @column annotation
	private String name;
	private String email;
	
	/*we will never keep the foreign key column as a part of the class structure
	private int addr_id; (NOT ALLOWED)*/
	
	@OneToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "addr_id") //fk
	private Address address; //has a relationship(association)
	//here addr_id is defined as address ie object of Address class

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
}
