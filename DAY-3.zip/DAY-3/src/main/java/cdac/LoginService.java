package cdac;

public class LoginService{
	public boolean loginCheck(String username, String password) {
		if(username.equals("dishi") && password.equals("123"))
			return true;
		return false;
	}

}
