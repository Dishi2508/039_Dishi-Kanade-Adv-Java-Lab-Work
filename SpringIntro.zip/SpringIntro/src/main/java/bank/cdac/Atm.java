package bank.cdac;

public interface Atm {
	
	public void withdraw(int acno, double amount);

}
