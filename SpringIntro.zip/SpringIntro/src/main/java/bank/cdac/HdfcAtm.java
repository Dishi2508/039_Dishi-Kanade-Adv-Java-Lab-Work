package bank.cdac;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("hdfcAtm-v2") //by default id will be same as class name
public class HdfcAtm implements Atm {
	
	@Autowired
	private List<Bank> banks; //loose coupling - hdfc atm can communicate to all bank atms when interface implemented and object is created by spring
	
	public void withdraw(int acno, double amount) {
		System.out.println("Customer at HdfcAtm wants to withdraw money");
		Bank currentBank = null;
		for(Bank bank : banks) {
			if(bank.isAccountPresent(acno)) {
				currentBank = bank;
				break;
			}
		}
		currentBank.withdraw(12345, acno, amount);
	}
}
