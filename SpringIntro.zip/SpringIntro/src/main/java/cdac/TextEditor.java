package cdac;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("txtEdtr")
public class TextEditor {
	 
	//in TextEditor class we require object of SpellChecker class
	
	@Autowired //Dependency Injection(DI)- we don't want to use bean to generate object(object created automatically)
	//class level annotation alternate of get bean
	private SpellChecker sp;
	
	public void load(String document) {
		System.out.println("some code here for loading " + document);
		//from here we want to invoke the spell checker
		
		//SpellChecker sp = new SpellChecker();
		//but we want Spring to create the required object for us
		sp.checkSpellingMistakes(document);
	}
}
