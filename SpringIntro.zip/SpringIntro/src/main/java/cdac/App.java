package cdac;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String args[]) {
		// Loading spring/IOC Container
		ApplicationContext ctx = new ClassPathXmlApplicationContext("my-spring-config.xml");

		// Accessing a particular bean
		HelloWorld hw = (HelloWorld) ctx.getBean("hello"); // get the object of HelloWorld using id hello created by spring
		//get bean return type is object so typecast to HelloWorld.
		System.out.println(hw.sayHello("Dishi"));

		// But why are we using Spring to create object of HelloWorld class?
		// We could have created object on our own like this:
		// HelloWorld hw = new HelloWorld();
		
		//By default Spring creates one object which used everywhere in your project
		
		Calculator c = (Calculator) ctx.getBean("calc");
		System.out.println(c.add(10, 20));
		System.out.println(c.sub(30, 20));
		
		CurrencyConverter cc = (CurrencyConverter) ctx.getBean("currencyConv");
		System.out.println(cc.convert("USD", "INR" , 650));
		
		LoginService loginServ = (LoginService) ctx.getBean("loginServ");
		System.out.println(loginServ.isValidUser("dishi", "456"));
		System.out.println(loginServ.isValidUser("dishi", "123"));
		
		TextEditor te = (TextEditor) ctx.getBean(("txtEdtr"));
		te.load("abc.txt");
		
		Car car = (Car) ctx.getBean("car");
		car.drive();
		
		Atm atm = (Atm) ctx.getBean(("hdfcAtm")); //object will be created of class but we will refer interface
		atm.withdraw(101010, 5000);
		
	}

}
