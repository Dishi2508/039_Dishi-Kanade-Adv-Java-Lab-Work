package cdac;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component //by default id will be same as class name
public class HdfcAtm implements Atm {
	
	@Autowired
	private Bank bank; //loose coupling - hdfc atm can communicate to all bank atms when interface implemented and object is created by spring
	public void withdraw(int acno, double amount) {
		System.out.println("Customer at HdfcAtm wants to withdraw money");
		bank.withdraw(12345, acno, amount);
	}
}
