package cdac;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String args[]) {

		ApplicationContext ctx = new ClassPathXmlApplicationContext("my-spring-config.xml");

		//CarPartsInventory inv = (CarPartsInventory) ctx.getBean("carParts1"); 
		
		// get bean is giving object of CarPartsInventoryImpl1 indirectly while talking to the interface(parent) as the same is implemented by the class
		// this is same as List(interface) and ArrayList(class)
		
		// Now manually create object of CarPart class
		
		//Model(class with getters and setters) or Entity classes are not instantiated using Spring
		
		/*CarPart cp = new CarPart();
		cp.setPartName("Nut & Bolt");
		cp.setCarModel("Maruti 800");
		cp.setPrice(500);
		cp.setQuantity(99);*/
		
		/*CarPart cp = new CarPart();
		cp.setPartName("Mirror");
		cp.setCarModel("Maruti 800");
		cp.setPrice(1500);
		cp.setQuantity(25);*/
		
		/*CarPart cp = new CarPart();
		cp.setPartName("AC");
		cp.setCarModel("Maruti 800");
		cp.setPrice(7500);
		cp.setQuantity(25);*/
		
		/*long ms1 = System.currentTimeMillis();
		//inv.addNewPart(cp);
		long ms2 = System.currentTimeMillis();
		System.out.println("Total Time Taken : " +(ms2 - ms1) + " ms approx"); //time taken to fire insert query in table (jdbc code)	*/
		
		CarPartsInventory inv = (CarPartsInventory) ctx.getBean("carParts2"); 
		
		/*CarPart cp = new CarPart();
		cp.setPartName("Mirror");
		cp.setCarModel("Maruti 800");
		cp.setPrice(1000);
		cp.setQuantity(95);
		
		long ms1 = System.currentTimeMillis();	
		inv.addNewPart(cp);
		long ms2 = System.currentTimeMillis();
		System.out.println("Total Time Taken : " +(ms2 - ms1) + " ms approx"); //time taken to fire insert query in table (jdbc code)	*/
		
		List<CarPart> list = inv.getAvailableParts();
		for(CarPart carPart : list)
			System.out.println(carPart);
		
	}
}
