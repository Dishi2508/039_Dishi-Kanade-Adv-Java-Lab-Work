package cdac;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

//todo - create table first tbl_cartpart in database

@Component("carParts2")
public class CarPartsInventoryImpl2 implements CarPartsInventory {

	// Connection Pool - to reduce the connection set up time b/w java app and database we use connection pool also known as DataSource
	@Autowired
	private DataSource dataSource; // create object of dataSource (injected)

	public void addNewPart(CarPart carPart) {
		Connection conn = null;
		try {
			// Class.forName("com.mysql.cj.jdbc.Driver"); -- no need to load driver will be
			// loaded automatically in bg now

			long ms1 = System.currentTimeMillis();
			conn = dataSource.getConnection();
			long ms2 = System.currentTimeMillis();
			System.out.println("Approx time taken to obtain a connection from the pool : " + (ms2 - ms1) + " ms"); // setting up connection takes the most amount of time.
			
			CallableStatement st = conn.prepareCall("{call add_carpart(?, ?, ?, ?) }");
			st.setString(1, carPart.getPartName());
			st.setString(2, carPart.getCarModel());
			st.setDouble(3, carPart.getPrice());
			st.setInt(4, carPart.getQuantity());
			st.executeUpdate();
			
			/*PreparedStatement st = conn.prepareStatement(
					"insert into tbl_carpart(part_name, car_model, price, quantity) values(?, ?, ?, ?)");
			st.setString(1, carPart.getPartName());
			st.setString(2, carPart.getCarModel());
			st.setDouble(3, carPart.getPrice());
			st.setInt(4, carPart.getQuantity());
			st.executeUpdate();*/

		} catch (SQLException e) {
			e.printStackTrace();
		}

		finally {
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
	}

	public List<CarPart> getAvailableParts() {
		Connection conn = null;
		try {
			conn = dataSource.getConnection();
			PreparedStatement st = conn.prepareStatement("select * from tbl_carpart");
			ResultSet rs = st.executeQuery(); //rs object created for select query
			
			List<CarPart> list = new ArrayList<>();
			while(rs.next()) { //header to first record - use of next
				CarPart carPart = new CarPart();
				carPart.setPartNo(rs.getInt(1));
				carPart.setPartName(rs.getString(2));
				carPart.setCarModel(rs.getString(3));
				carPart.setPrice(rs.getDouble(4));
				carPart.setQuantity(rs.getInt(5));
				list.add(carPart); //runs = count of data in db
			}
			return list;
		}
		catch (SQLException e) {
			e.printStackTrace();
			return null;
		}

		finally {
			try {
				conn.close();
			} catch (Exception e) {
			}
		}
		//return null;
	}
}
